/*Hello  World Program */
#include<stdio.h>
int

main(void)
{
printf("Hello world is a program used by hackers to test programs.");
return 0;
}
